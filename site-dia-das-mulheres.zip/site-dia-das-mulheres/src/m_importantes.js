import React from 'react';

function MImportantes() {
  return (
    <div>
      <h1>Mulheres Importantes para Nós</h1>
  
    </div>
  );
}

export default MImportantes;
