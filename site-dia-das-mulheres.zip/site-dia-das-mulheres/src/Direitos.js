import React from 'react';

function Direitos() {
  return (
    <div>
      <h1>Direitos das Mulheres</h1>
      <p>Conteúdo relacionado aos direitos das mulheres...</p>
    </div>
  );
}

export default Direitos;
