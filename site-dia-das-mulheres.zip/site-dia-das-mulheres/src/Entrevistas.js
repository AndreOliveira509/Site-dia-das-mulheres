import React from 'react';

function Entrevistas() {
  return (
    <div>
      <h1>Entrevistas</h1>
      <p>Aqui estão algumas entrevistas com mulheres íncrivies da ETEC Bartô</p>
    </div>
  );
}

export default Entrevistas;
